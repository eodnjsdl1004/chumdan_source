String.prototype.replaceAll = function(org, dest) {
    return this.split(org).join(dest);
}
function dateFormat(str) {
	if(str!=null && str.length==14) {
		return str.substring(0,4)+"."+str.substring(4,6)+"."+str.substring(6,8)+" "+str.substring(8,10)+":"+str.substring(10,12)+":"+str.substring(12,14);
	}	
}
//스크롤바 없고 위치 지정 일반팝업
function popwin_position(url,w,h,h_percent,w_percent) 
{
	var ScreenW = window.screen.width;
	var ScreenH = window.screen.height;
	var top = ScreenH*(h_percent*0.1);
	var left = ScreenW*(w_percent*0.1);

	window.open(url,"","top="+ top +",left="+ left +",width="+ w +",height="+ h +",scrollbars=no,resizable=no,toolbar=no");	
}

//스크롤바 없는 일반팝업
function popwin(url,w,h) 
{
    window.open(url,'','width='+w+',height='+h+',scrollbars=no,resizable=no,toolbar=no,top=100,left=100');
}

//스크롤바 있는 일반팝업
function popwin_roll(url,w,h) 
{
    window.open(url,'','width='+w+',height='+h+',scrollbars=yes,resizable=no,toolbar=no,top=10,left=10');
}

//창이름이 있어야 하는 팝업
function popwin_name(url,name,w,h) 
{
    window.open(url,name,'width='+w+',height='+h+',scrollbars=no,resizable=no,toolbar=no,top=10,left=10');
}

//스크롤바 없고 창이름 있는 팝업
function popsn(url,name,w,h) 
{
    window.open(url,name,'width='+w+',height='+h+',scrollbars=no,resizable=no,copyhistory=no,toolbar=no,top=10,left=10');
}

//스크롤바 있고 창이름 있는 팝업
function popsy(url,name,w,h) 
{
    window.open(url,name,'width='+w+',height='+h+',scrollbars=yes,resizable=no,copyhistory=no,toolbar=no,top=10,left=10');
}

//null 또는 undefined 면 빈값 리턴 (returnStr가 있을경우에는 returnStr를 리턴)
function null2void(strObj, returnStr) {
	if(isEmpty(strObj)) {
		if(isEmpty(returnStr)) {
			return "";
		} else {
			return returnStr;
		}
	} else {
		return strObj;
	}
}
//비어있는지 체크
function isEmptyMsg(strObj, alertMsg) {
	if(isEmpty(strObj.value)) {
		alert(alertMsg);
		strObj.focus();
		return true;
	} else {
		return false;
	}
}
//비어있는지 체크
function isEmpty(str) {
 if( str != null )
 {
  for( i=0 ; i < str.length ; i++)
  {
   if( !isWhiteChar( str.charAt(i) ) )
    return false;
  }
 }
 return ((str == null) || (str.length == 0));
}
//스페이스바
function isWhiteChar(c){
	return (c == ' ' || c == '\t' || c == '\n' || c == '\r')
}

function checkRadioValue(obj) {
    var i, sum=0;
    var robj = document.getElementsByName(obj);
    for(i=0;i<robj.length;i++){
        if(robj[i].checked == true){
            sum++;
        } 
    }
    if(sum == 0) {
        return false;
    } else  {
    	return true;
    }
}

function setCookie(name,value){
	var argc = setCookie.arguments.length;
	var argv = setCookie.arguments;

	var expires = ( argc > 2) ? argv[2]:null;
	var path = ( argc > 3) ? argv[3]:null;
	var domain = ( argc > 4) ? argv[4]:null;
	var secure = ( argc > 5) ? argv[5]:false;

	document.cookie = name + "=" + escape(value) +
		((expires == null) ? "" : ("; expires =" + expires.toGMTString())) +
		((path == null) ? "" : ("; path =" + path)) +
		((domain == null) ? "" : ("; domain =" + domain)) +
		((domain == true) ? "; secure" : "");
}

function getCookie (name) {
	var dcookie = document.cookie;
	var cname = name + "=";
	var clen = dcookie.length;
	var cbegin = 0;
	while (cbegin < clen) {
		var vbegin = cbegin + cname.length;
			if (dcookie.substring(cbegin, vbegin) == cname) {
				var vend = dcookie.indexOf (";", vbegin);
				if (vend == -1) vend = clen;
			return unescape(dcookie.substring(vbegin, vend));
		}
		cbegin = dcookie.indexOf(" ", cbegin) + 1;
		if (cbegin == 0) break;
	}
	return "";
}

function getTodayWithTime() {
	var now = new Date();
	var year = now.getFullYear();
	var month = now.getMonth()+1;
	var day = now.getDate();
	var hh = now.getHours();
    var mm = "30";
    var ss = now.getSeconds();

	  if ( month < 10) {
	    month = "0"+month;
	   }
	  if ( day < 10) {
	    day = "0"+day;
	  }
	var today = year+''+month+''+day+hh+''+mm+''+ss;
	return today;
}

function onlyNumber(obj, inputVal) {
	// 숫자만인지 체크하는 정규식
	var regNumber = /^[\,\,0,1,2,3,4,5,6,7,8,9]*$/;
	//var regNumber = /^[\,\,0,1,2,3,4,5,6,7,8,9,/]/; // 숫자와 , 만 가능
	var str = obj.value;
	if(!regNumber.test(inputVal)) {
		obj.value = str.substring(0,str.length-1);
	    alert('숫자만 입력해주세요.');
	    return;
	}
}

function numberWithCommas(x) {
	x = removeComma(x);
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function removeComma(n) {  // 콤마제거
    if ( typeof n == "undefined" || n == null || n == "" ) {
        return "";
    }
    var txtNumber = '' + n;
    return txtNumber.replace(/(,)/g, "");
}

//제곱미터를 Float 값을 받아서 평수를 리턴 또는 반대로도 가능. obj에 값을 넣어줌
function roomCalculator(chk, floatVal, obj){
  if(chk==1){ 
	  //평 -> m2
	  document.getElementById(obj).value = parseFloat(floatVal) * 3.3058;
  }
  else {
	  //m2 -> 평
	  document.getElementById(obj).value = parseFloat(floatVal) / 3.3058;
  }
}

//객체가 undefined인지 체크
function _emptyObject(obj) {
	try {
		if(typeof(obj)=='undefined'){
			return true;
		} else {
			if(isEmpty(obj)) {
				return true;
			} else {
				return false;
			}
		}	
	} catch (e) {
		return true;
	}
}

//마커객체가 지도에 있으면 지도에서 삭제 한다.
function _objectDelete(obj) {
	if(!_emptyObject(obj)) { obj.setMap(null); }
}

function TextAbstract(text, length) {
    if (text == null) {
        return "";
    }
    if (text.length <= length) {
        return text;
    }
    text = text.substring(0, length);
    last = text.lastIndexOf(" ");
    text = text.substring(0, last);
    return text + "...";
}

