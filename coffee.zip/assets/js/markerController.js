/*
0 : 신고접수마커
1 : 검색마커
2 : 서소마커
3 : 차량마커
4 : 화재
5 : 구조
6 : 구급
7 : 기타
8 : 소방용수
9 : 집중추적차량
10 : 전신주
11 : 대상물
*/
var _marker0, _marker1, _marker2, _marker3, _marker4, _marker5, _marker6, _marker7, _marker8, _marker9, _marker10, _marker11;
var _marker0Info, _marker1Info, _marker2Info, _marker3Info, _marker4Info, _marker5Info, _marker6Info, _marker7Info, _marker8Info, _marker9Info, _marker10Info, _marker11Info;
var _allMarkerCount = 12;	//총 생성할 수 있는 마커 갯수
var _infoWindowCloseFlag = false;	//정보창 닫기 버튼 여부
var roadViewOpen = false;	//로드뷰가 열려 있는지 확인
var isDSR = false;	//재난 마커를 표시중인지 여부
var infoUpdateFlag = false;


var nowSingoLat;
var nowSingoLng;

//마커 종류에 따라 "한개의" 마커생성를 생성하고 infoWindow를 생성한다.
/*
 *  @ param 
 *  lat : lat
 *  lng : lng
 *  markerType : 마커 번호
 *  infoMsg : 정보창 메세지
 *  moveFlag : 중심점 이동 여부 ( default : 중심점이동 )
 *  draggableFlag : 드레그 가능여부
 *  newYn : 임의의 새로운 마커 생성 여부 (Y or N)
 *  newObjNm : 임의의 새로운 마커 이름. (컨트롤 할때 이 이름으로 컨트롤 할 수 있음)
 */
function _makeMarker(lat, lng, markerType, infoMsg, moveFlag, draggableFlag, newYn, newObjNm) {
	if(isEmpty(draggableFlag)) {
		alert("드레그 가능 여부를 지정하세요.");
		return;
	}
	if(markerType==4 || markerType==5 || markerType==6 || markerType==7){
		isDSR = true;	//재난마커표시중
	} else {
		isDSR = false;
	}
	
	var mapMoveYn = true;
	if(!isEmpty(moveFlag) && !moveFlag) {
		mapMoveYn = false;
	}
	
	if (parseInt(lat, 10) > 50) {
		//alert("WTM 좌표계를 변경합니다.");
		//WTM 좌표체계이면 WGS84 좌표계의 좌표로 변환해서 다시 호출 합니다.
		wtmTempMarkerType = markerType;
		wtmTempInfoMsg = infoMsg;
		wtmTempMoveFlag = moveFlag;
		wtmTempDraggableFlag = draggableFlag;
		
		var geocoder = new daum.maps.services.Geocoder(), // 좌표계 변환 객체를 생성합니다
		wtmX = lat, // 변환할 WTM X 좌표 입니다
		wtmY = lng; // 변환할 WTM Y 좌표 입니다

		// WTM 좌표를 WGS84 좌표계의 좌표로 변환합니다
		geocoder.transCoord(wtmX, wtmY, daum.maps.services.Coords.TM, // 변환을 위해 입력한 좌표계입니다
		daum.maps.services.Coords.WGS84, // 변환 결과로 받을 좌표계 입니다
		wtmToWgs84Callback); // 변환 결과를 받을 콜백합수 입니다
		return;
	}
	
	// 마커가 표시될 위치입니다
	var markerPosition = new daum.maps.LatLng(lat, lng);
	
	var markerStyle = new daum.maps.Marker({
		position : markerPosition,
		draggable : draggableFlag,
		image : _setMarkerImage(markerType),
	});
	
	if(!isEmpty(newYn) && newYn=="Y") {
		if(isEmpty(newObjNm)) {
			alert("새로운 마커를 생성할때에는 Object Name 가 필수 입니다.");
			return;
		} else {
			if(isEmpty(infoMsg)) {
				alert("새로운 마커를 생성할때에는 InfoWindow 가 필수 입니다.");
				return;
			}
			
			//새로운 마커를 생성한다.
			var isEmptyTypeObject = false;
			eval("if(typeof "+newObjNm+" == 'undefined') { isEmptyTypeObject = true; } else { isEmptyTypeObject = false; }  ");
			
			if(!isEmptyTypeObject) {
				if(!_emptyObject(eval(newObjNm))) {
					eval("_objectDelete("+newObjNm+");");	
					_infoWindowDelete(eval(newObjNm+"Info"));	
				}
			}
			
			eval(newObjNm + " = markerStyle;");
			eval(newObjNm+".setMap(map);");
			
			if(mapMoveYn) {
				map.setCenter(markerPosition);
			}
			
			var infoWindowObjectHtml = "<div style='padding:5px;'>"+infoMsg+"</div>";
			if(infoMsg!=null && infoMsg!='') {
				//정보창에 나타낼 메세지가 있으면,,,
				eval(newObjNm+"Info=new daum.maps.InfoWindow({content : infoWindowObjectHtml,removable : _infoWindowCloseFlag});");
				eval(newObjNm+"Info.open(map, "+newObjNm+");");		
			}
			
			if(draggableFlag) {
				// 마커에 dragend 이벤트를 등록합니다
				daum.maps.event.addListener(markerStyle, 'dragend', function() {
					var currentMarkerLat = markerStyle.getPosition().wb;
					var currentMarkerLng = markerStyle.getPosition().vb;	
					
					nowSingoLat = currentMarkerLat;
					nowSingoLng = currentMarkerLng;
					
					if(infoMsg!=null && infoMsg!='') {
						//정보창에 나타낼 메세지가 있으면,,,
						if(!_emptyObject(eval(newObjNm+"Info"))) {
							_infoWindowDelete(eval(newObjNm+"Info"));
						}		
						eval(newObjNm+"Info=new daum.maps.InfoWindow({content : infoMsg, removable : _infoWindowCloseFlag});");
						eval(newObjNm+"Info.open(map, "+newObjNm+");");
					}
					
					//로드뷰를 보고 있었으면..변경된 위치로 보여줘야함.loadRoadView()
					if(roadViewOpen) {
						makeRoadView(currentMarkerLat, currentMarkerLng);
					}	
				});
			}
			return;
		}
	}
	
	if(isDSR) {
		//재난 마커 일경우에는 재난 마커 모두 삭제
		for(var i=4; i<=7; i++){
			eval("_objectDelete(_marker"+i+");");	
			_infoWindowDelete(eval("_marker"+i+"Info"));
		}
	} else {
		//재난 마커가 아닐경우에는 하나만 삭제해줌.
		eval("_objectDelete(_marker"+markerType+");");
	}
	eval("_marker"+markerType+" = markerStyle;");
	eval("_marker"+markerType+".setMap(map);");
	
	// 지도 중심을 이동 시킵니다
	console.log("mapMoveYn : " + mapMoveYn);
	console.log("draggableFlag : " + draggableFlag);
	if(mapMoveYn) {
		map.setCenter(markerPosition);
	}
	
	var infoWindowObjectHtml = "<div style='padding:5px;'>"+infoMsg+"</div>";
	if(infoMsg!=null && infoMsg!='') {
		//정보창에 나타낼 메세지가 있으면,,,
		if(!_emptyObject(eval("_marker"+markerType+"Info"))) {
			_infoWindowDelete(eval("_marker"+markerType+"Info"));
		}		
		eval("_marker"+markerType+"Info=new daum.maps.InfoWindow({content : infoWindowObjectHtml,removable : _infoWindowCloseFlag});");
		
		eval("_marker"+markerType+"Info.open(map, _marker"+markerType+");");		
	}
	
	if(draggableFlag) {
		// 마커에 dragend 이벤트를 등록합니다
		daum.maps.event.addListener(markerStyle, 'dragend', function() {
			var currentMarkerLat = markerStyle.getPosition().wb;
			var currentMarkerLng = markerStyle.getPosition().vb;	
			
			nowSingoLat = currentMarkerLat;
			nowSingoLng = currentMarkerLng;
			
			if(infoMsg!=null && infoMsg!='') {
				//정보창에 나타낼 메세지가 있으면,,,
				if(!_emptyObject(eval("_marker"+markerType+"Info"))) {
					_infoWindowDelete(eval("_marker"+markerType+"Info"));
				}		
				eval("_marker"+markerType+"Info=new daum.maps.InfoWindow({content : infoMsg, removable : _infoWindowCloseFlag});");
				
				eval("_marker"+markerType+"Info.open(map, _marker"+markerType+");");		
			}
			
			//로드뷰를 보고 있었으면..변경된 위치로 보여줘야함.loadRoadView()
			if(roadViewOpen) {
				makeRoadView(currentMarkerLat, currentMarkerLng);
			}	
			
			/*
			// lat, lng 를 TM 변환해서 업데이트
			var url = "/getWTM.act";
			try {
				$.ajax({
					url : url,
					type : "POST",
					data : {
						'url_x' : nowSingoLng,
						'url_y' : nowSingoLat,
						'dsr_seq' : nowCtlAccdSeq
					},
					success : function(data, textStatus) {						
						//webSocket.send("UDPIPC6382-100000;ERSS_GIS;"+makeDateNumber()+";"+(m_SendSeq++)+";10081;"+dsrNowApply+";");
					}
				});			
			} catch (e) {
				alert(e.description);
			}
			//fncGetDsrWtm();
			
			//coord2addr(currentMarkerLat, currentMarkerLng, "coord2addrCallback");		
			
			coord2detailAddr(currentMarkerLat, currentMarkerLng, "coord2addrCallback");

			//자동으로 인근 서/센터를 로딩함.
			//singoSelect(currentMarkerLat, currentMarkerLng);
						
			infoUpdateFlag = true;
			*/	
					
		});
	}else{
		//customPanTo(nowSingoLat, nowSingoLng);		
	}	
}

//주소를 입력받아 하나의 마커를 생성 합니다.
function _makeMarkerFromAddr(addrStr, markerType, infoMsg) {
	// 주소-좌표 변환 객체를 생성합니다
	var geocoder = new daum.maps.services.Geocoder();

	// 주소로 좌표를 검색합니다
	geocoder.addressSearch(addrStr, function(status, result) {

		// 정상적으로 검색이 완료됐으면
		if (status === daum.maps.services.Status.OK) {
			// 결과값으로 받은 위치를 마커로 표시합니다
			_makeMarker(result.addr[0].lat, result.addr[0].lng, markerType, infoMsg);
			
		} else {
			alert("주소의 좌표값을 찾을 수 없습니다.");
		}
	});
}

function _setMarkerImage(num) {
	if (isEmpty(num)) {
		alert('마커 필수 옵션 인자가 비어 있습니다.[1]');
		return;
	}
	var imageSrc = '/assets/images/marker-' + num + '.png',
					//imageSize = new daum.maps.Size(64, 75),// 마커 크기
					imageSize = new daum.maps.Size(34, 46),// 마커 크기
					imageOption = {
									offset : new daum.maps.Point(17, 23) 
					};// 마커 중심점 위치

	// 마커의 이미지정보를 가지고 있는 마커이미지를 생성합니다
	return new daum.maps.MarkerImage(imageSrc, imageSize, imageOption);
}

function _setDefaultMarkerImage(num) {
	if (isEmpty(num)) {
		alert('마커 필수 옵션 인자가 비어 있습니다.[0]');
		return;
	}

	var imageSrc = '/img/map/defaultMarker' + num + '.png',
					imageSize = new daum.maps.Size(32, 32),// 마커 크기
					imageOption = {
									offset : new daum.maps.Point(16, 16)
					};// 마커 중심점 위치

	// 마커의 이미지정보를 가지고 있는 마커이미지를 생성합니다
	return new daum.maps.MarkerImage(imageSrc, imageSize, imageOption);
}

//WGS84 좌표계의 좌표로 변환 후 Callback
var wtmTempMarkerType, wtmTempInfoMsg, wtmTempMoveFlag, wtmTempDraggableFlag; //전달할 임시변수
function wtmToWgs84Callback(status, result) {
	if (status === daum.maps.services.Status.OK) {
		_makeMarker(result.y, result.x, wtmTempMarkerType, wtmTempInfoMsg, wtmTempMoveFlag, wtmTempDraggableFlag);
	} else {
		alert("좌표변환에 실패하였습니다.");
		return;
	}
}

/*
 * 두 지점간의 최단거리를 리턴한다.
 * sLat, sLng : WGS84좌표체계
 * eLat, eLng : DB에 들어있는 WCONGNAMUL 좌표체계 
 */
 
function getMinDitanceWithDaum(sLat, sLng, eLat, eLng, callbackFunction) {
	$('#loadingbar').show();
	var wStartLat, wStartLng;
	
	var url = "/transCoord.act";
	try {
		$.ajax({
			url : url,
			type : "POST",
			data : {
				'wgs_x' : sLat,
				'wgs_y' : sLng
			},
			success : function(data, textStatus) {
				var resultData = JSON.parse(data);
				wStartLat = resultData[0].wcong_x;
				wStartLng = resultData[0].wcong_y;
				getMinDistanceCallBack(wStartLat, wStartLng, eLat, eLng, callbackFunction);
			}
		});
	} catch (e) {
		alert(e.description);
		$('#loadingbar').hide();
	}
}
function getMinDistanceCallBack(wStartLat, wStartLng, eLat, eLng, callbackFunction){

	var url = "/getMinDistance.act";
	try {
		$.ajax({
			url : url,
			type : "POST",
			data : {
				'wgs_x' : wStartLat,
				'wgs_y' : wStartLng,
				'url_x' : eLat,
				'url_y' : eLng
			},
			success : function(data, textStatus) {
				var resultData = JSON.parse(data);
				//alert(resultData[0].distance);
				getMinDistanceFinnalyCallback(resultData[0].distance, callbackFunction);
			}
		});
	} catch (e) {
		alert(e.description);
		$('#loadingbar').hide();
	}
}
function getMinDistanceFinnalyCallback(distance, callbackFunction) {
	$('#loadingbar').hide();
	if(callbackFunction.indexOf(":Param:")>0) {
		var paramArr = callbackFunction.split(":Param:");
		if(paramArr.length==4) {
			eval(paramArr[0]+"('"+distance+"','"+paramArr[1]+"','"+paramArr[2]+"','"+paramArr[3]+"');");	
		}
	}
}
/*

function makeRoadView(pLat, pLng) {
	
	var roadviewContainer = document.getElementById('roadview'); //로드뷰를 표시할 div
	var roadview = new daum.maps.Roadview(roadviewContainer); //로드뷰 객체
	var roadviewClient = new daum.maps.RoadviewClient(); //좌표로부터 로드뷰 파노ID를 가져올 로드뷰 helper객체

	var position = null;
	if(_emptyObject(pLat)) {
		position = new daum.maps.LatLng(nowSingoLat, nowSingoLng);
	} else {
		position = new daum.maps.LatLng(pLat, pLng);
	}

	// 특정 위치의 좌표와 가까운 로드뷰의 panoId를 추출하여 로드뷰를 띄운다.
	roadviewClient.getNearestPanoId(position, 50, function(panoId) {
	    roadview.setPanoId(panoId, position); //panoId와 중심좌표를 통해 로드뷰 실행
	});
	$("#roadViewdiv").show();
}
*/
function closeRoadView() {
	$("#roadViewdiv").hide();
	roadViewOpen = false;
}
function loadRoadView() {
	if (_emptyObject(nowSingoLat)) {
		alert("신고자 위치를 먼저 검색해주세요.");
		return;
	}
	if(!roadViewOpen) {
		makeRoadView();
		roadViewOpen = true;
	} else {
		$("#roadViewdiv").hide();
		roadViewOpen = false;
	}
}

//배열안에 있는 마커들 모두 보이기
function showMarkers(markerArr) {
	for (var i = 0; i < markerArr.length; i++) {
		markerArr[i].setMap(map);
  } 
}

//배열안에 있는 마커들 모두 삭제
function hideMarkers(markerArr) {
	for (var i = 0; i < markerArr.length; i++) {
		markerArr[i].setMap(null);
    } 
}

var showTrafficFlag = false;
function toggleTraffic() { 
	if(!showTrafficFlag) {
		//지도에 교통정보를 표시하도록 지도타입을 추가합니다
		map.addOverlayMapTypeId(daum.maps.MapTypeId.TRAFFIC);
		showTrafficFlag = true;
	}  else {
		map.removeOverlayMapTypeId(daum.maps.MapTypeId.TRAFFIC);
		showTrafficFlag = false;
	}
	
}

// 좌표 -> 주소
function coord2addr(lat, lng, callback, tp) {
	
	alert("lat : " + lat + ", lng : " + lng);
	
	if(isEmpty(tp)) { tp = "WGS84"; }
	var oScript = document.createElement('script');
    oScript.type ='text/javascript';
    oScript.charset ='utf-8';          
    oScript.src = 'https://apis.daum.net/local/geo/coord2addr?apikey=' + apiKey + 
                  '&latitude=' + '' + lat + '' + '&longitude=' + '' + lng + '' +
                  '&inputCoordSystem=' + tp + '&output=json&callback=' + callback + '';
    console.log(oScript.src);
    document.getElementsByTagName('head')[0].appendChild(oScript);
}

// 주소 -> 좌표
function addr2coord(addr, callback) {
	var oScript = document.createElement('script');
	oScript.type ='text/javascript';
	oScript.charset ='utf-8';          
	oScript.src = 'https://apis.daum.net/local/geo/addr2coord?apikey=' + apiKey + 
	'&q=' + ''+ encodeURIComponent(addr) + '' + '&output=json&callback=' + callback + '';
	console.log(oScript.src);
	document.getElementsByTagName('head')[0].appendChild(oScript);		
}

//좌표 -> 상세주소
//x에 lng , y에 lat 가 들어가야함.
//결과ex) {"new":{"bunji":"111","ho":"","name":"광주광역시 서구 내방로 111","roadName":"내방로"},"regionId":"E13041500","old":{"bunji":"1200","san":"N","ho":"","name":"광주 서구 치평동 1200"},"x":126.85160812218967,"y":35.16003883814977,"region":"광주 서구 치평동","bcode":"2914012000"})
function coord2detailAddr(lat, lng, callback, tp) {
	if(isEmpty(tp)) { tp = "WGS84"; }
	var oScript = document.createElement('script');
    oScript.type ='text/javascript';
    oScript.charset ='utf-8';          
    oScript.src = 'https://apis.daum.net/local/geo/coord2detailaddr?apikey=' + apiKey + 
                  '&x=' + ''+lng+'' + '&y=' + ''+lat+'' +
                  '&inputCoordSystem='+tp+'&output=json&callback='+callback+'';
    
    //alert("=======================================" + oScript.src);
    
    console.log(oScript.src);
    document.getElementsByTagName('head')[0].appendChild(oScript);
}

//마커의 info window에 메세지 넣기
//markerType : 마커구분
//infoMsg : 메세지
function updateMarkerInfo(markerType, infoMsg) {
	if(isEmpty(markerType)) { alert('마커구분이 비었습니다.'); return; }
	if(isEmpty(infoMsg)) { alert('InfoWindow의 메세지를 입력해주세요.'); return; }
	
	var infoWindowObjectHtml = "<div style='padding:5px;'>"+infoMsg+"</div>";
	
	if(!_emptyObject(eval("_marker"+markerType+"Info"))) {
		_infoWindowDelete(eval("_marker"+markerType+"Info"));
		eval("_marker"+markerType+"Info=new daum.maps.InfoWindow({content : infoWindowObjectHtml,removable : _infoWindowCloseFlag});");
		eval("_marker"+markerType+"Info.open(map, _marker"+markerType+");");
	} else {
		alert(markerType+'마커가 없습니다.');
		return;
	}
}

/*function coord2addrCallback(data, textStatus) {
	data = '{"name1":"Jesper","surname":"Aaberg","phone":["555-0100","555-0120"]}';
	var resultData = JSON.parse(data);
	alert(resultData.name1);
}*/
/***********************************************************************
 * 기타 util 함수
 * *********************************************************************/
//객체가 undefined인지 체크
function _emptyObject(obj) {
	try {
		if(typeof(obj)=='undefined'){
			return true;
		} else {
			if(isEmpty(obj)) {
				return true;
			} else {
				return false;
			}
		}	
	} catch (e) {
		return true;
	}
}

//마커객체가 지도에 있으면 지도에서 삭제 한다.
function _objectDelete(obj) {
	if(!_emptyObject(obj)) { obj.setMap(null); }
}
//InfoWindow객체가 지도에 있으면 지도에서 삭제 한다.
function _infoWindowDelete(obj) {
	if(!_emptyObject(obj)) { obj.close(); }
}

//맵상에 있는 마커와 infoWindow를 모두 삭제한다.
function _allObjectDelete() {
	for (var i=0; i<_allMarkerCount; i++) {
		eval("_objectDelete(_marker"+i+");");
		eval("_infoWindowDelete(_marker"+i+"Info);");
	}
	for (var i=0; i<4; i++) {
		eval("_objectDelete(findCenterMarker"+i+");");
		eval("_infoWindowDelete(findCenterMarkerInfo"+i+");");
	}
	//nowSingoLat=null;
	//nowSingoLng=null;
}
