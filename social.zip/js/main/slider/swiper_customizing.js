    var swiper = new Swiper('.swiper-container', {
        pagination: '.swiper-pagination',
        paginationClickable: true,
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        autoHeight: true, //enable auto height
        loop: true, // infinite-loop
        slidesPerView: 1, //view
        paginationClickable: true,
        spaceBetween: 30,
        autoplay: 5000, //time
        keyboardControl: true,// key
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        grabCursor: true,
    });

//시간,그랩,키,무한 등등 customizing 2017-06-26
