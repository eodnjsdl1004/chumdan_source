$(document).ready(function(){
            $(".main_menu_list").hover(function(){
               $(this).find("ul ul").stop().fadeToggle(100);
               $(this).find(".list_none_box").stop().fadeToggle(100);
            });//End of main_menu_list
            
             $(".M_top_menu").click(function(){
                  $('.M_top_menu_1,.M_top_menu_1_back').slideToggle(100).toggleClass('dis');
             });
            $(".M_top_menu_1_back").click(function(){
                $('.M_top_menu_1,.M_top_menu_1_back').slideToggle(100).toggleClass('dis');
             });
            $(".close").click(function(){
                $('.M_top_menu_1,.M_top_menu_1_back').slideToggle(100).toggleClass('dis');
             });
            $(".M_top_menu_1 ul li").click(function(){     		
                $(this).parent().find("ul").stop().slideToggle(200);
             });// End of M_box
            
             $(".sub_1_menu ul li").click(function(){
               $(this).parent().find("ul").stop().slideToggle(100);
            });//End of main_menu_list
            
        }); 
